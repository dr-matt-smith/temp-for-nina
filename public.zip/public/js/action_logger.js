

let currentDroppable = null;

let trail = {
    events: []
};

let timeStartExperiment = Date.now();

let ball = document.getElementById("draggable");

ball.onmousedown = function(event) {

    var newEvent = {
        "time":  timeSinceDragStartSeconds(),
        "type": "mouseDown",
        "x" : 0,
        "y": 0
    };

    logNewEvent(newEvent);

    let shiftX = event.clientX - ball.getBoundingClientRect().left;
    let shiftY = event.clientY - ball.getBoundingClientRect().top;

    ball.style.position = 'absolute';
    ball.style.zIndex = 1000;
    document.body.append(ball);

    moveAt(event.pageX, event.pageY);

    function moveAt(pageX, pageY) {
        ball.style.left = pageX - shiftX + 'px';
        ball.style.top = pageY - shiftY + 'px';
    }

    function onMouseMove(event) {
        moveAt(event.pageX, event.pageY);


        // var positionString = "[time: " + timeSinceDragStartSeconds + ": (" + event.pageX + ", " + event.pageY + ")], ";

        var newEvent = {
            "time":  timeSinceDragStartSeconds(),
            "type": "drag",
            "x" : event.pageX,
            "y": event.pageY
        };


        logNewEvent(newEvent);

        ball.hidden = true;
        let elemBelow = document.elementFromPoint(event.clientX, event.clientY);
        ball.hidden = false;

        if (!elemBelow) return;

        let droppableBelow = elemBelow.closest('#droppable');
        if (currentDroppable != droppableBelow) {
            if (currentDroppable) { // null when we were not over a droppable before this event
                leaveDroppable(currentDroppable);
            }
            currentDroppable = droppableBelow;
            if (currentDroppable) { // null if we're not coming over a droppable now
                // (maybe just left the droppable)
                enterDroppable(currentDroppable);
            }
        }
    }

    document.addEventListener('mousemove', onMouseMove);

    ball.onmouseup = function() {
        document.removeEventListener('mousemove', onMouseMove);
        ball.onmouseup = null;
    };

};

function enterDroppable(elem) {
    elem.style.background = 'pink';

    var newEvent = {
        "time":  timeSinceDragStartSeconds(),
        "type": "enterDroppable",
        "x" : 0,
        "y": 0
    };

    logNewEvent(newEvent);
}

function timeSinceDragStartSeconds()
{
    var timeSinceDragStartMilliseconds = Date.now() - timeStartExperiment;
    return timeSinceDragStartMilliseconds / 1000;
}


function leaveDroppable(elem) {
    elem.style.background = '';
}

ball.ondragstart = function() {
    return false;
};


function logNewEvent(newEvent){
    console.log(newEvent);

    $.ajax({
        url: "https://logger.frb.io"
//        url: "localhost:8000"
            + "/" + "api"
            + "/" + application
            + "/" + participant
            + "/" + experimentNumber
            + "/" + newEvent.time
            + "/" + newEvent.x
            + "/" + newEvent.y
            + "/" + newEvent.type,

        // data: {
        //     apikey: my_apikey
        // },
        // data: "",
        method: 'GET',
        crossDomain: true,
        "headers": {
            "accept": "application/x-www-form-urlencoded",
            "Access-Control-Allow-Origin":"*"

        }
        // type: 'POST',
        // success: function(res) {
        //     console.log(res);
        // }
    });

}

